    </main> <!-- End main content -->
</div> <!-- End flex container -->
</div> <!-- End #app-container -->

<!-- Custom JS -->
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>